﻿namespace Keypad
{
    partial class Keyboard
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_3 = new System.Windows.Forms.Button();
            this.btn_u = new System.Windows.Forms.Button();
            this.btn_i = new System.Windows.Forms.Button();
            this.btn_o = new System.Windows.Forms.Button();
            this.btn_p = new System.Windows.Forms.Button();
            this.btn_a = new System.Windows.Forms.Button();
            this.btn_s = new System.Windows.Forms.Button();
            this.btn_d = new System.Windows.Forms.Button();
            this.btn_f = new System.Windows.Forms.Button();
            this.btn_g = new System.Windows.Forms.Button();
            this.btn_h = new System.Windows.Forms.Button();
            this.btn_j = new System.Windows.Forms.Button();
            this.btn_k = new System.Windows.Forms.Button();
            this.btn_l = new System.Windows.Forms.Button();
            this.btn_z = new System.Windows.Forms.Button();
            this.btn_x = new System.Windows.Forms.Button();
            this.btn_c = new System.Windows.Forms.Button();
            this.btn_v = new System.Windows.Forms.Button();
            this.btn_b = new System.Windows.Forms.Button();
            this.btn_n = new System.Windows.Forms.Button();
            this.btn_m = new System.Windows.Forms.Button();
            this.btn_space = new System.Windows.Forms.Button();
            this.btn_clear = new System.Windows.Forms.Button();
            this.btn_1 = new System.Windows.Forms.Button();
            this.btn_2 = new System.Windows.Forms.Button();
            this.btn_4 = new System.Windows.Forms.Button();
            this.btn_8 = new System.Windows.Forms.Button();
            this.btn_9 = new System.Windows.Forms.Button();
            this.btn_7 = new System.Windows.Forms.Button();
            this.btn_q = new System.Windows.Forms.Button();
            this.btn_0 = new System.Windows.Forms.Button();
            this.btn_5 = new System.Windows.Forms.Button();
            this.btn_6 = new System.Windows.Forms.Button();
            this.btn_w = new System.Windows.Forms.Button();
            this.btn_e = new System.Windows.Forms.Button();
            this.btn_r = new System.Windows.Forms.Button();
            this.btn_t = new System.Windows.Forms.Button();
            this.btn_y = new System.Windows.Forms.Button();
            this.btn_cancel = new System.Windows.Forms.Button();
            this.btn_OK = new System.Windows.Forms.Button();
            this.btn_backspace = new System.Windows.Forms.Button();
            this.chk_shift = new System.Windows.Forms.CheckBox();
            this.chk_capslock = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // btn_3
            // 
            this.btn_3.BackColor = System.Drawing.SystemColors.Control;
            this.btn_3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_3.Location = new System.Drawing.Point(151, 8);
            this.btn_3.Name = "btn_3";
            this.btn_3.Size = new System.Drawing.Size(72, 72);
            this.btn_3.TabIndex = 0;
            this.btn_3.TabStop = false;
            this.btn_3.Text = "3";
            this.btn_3.UseVisualStyleBackColor = false;
            this.btn_3.Click += new System.EventHandler(this.Btn_3_Click);
            // 
            // btn_u
            // 
            this.btn_u.BackColor = System.Drawing.SystemColors.Control;
            this.btn_u.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_u.Location = new System.Drawing.Point(462, 83);
            this.btn_u.Name = "btn_u";
            this.btn_u.Size = new System.Drawing.Size(72, 72);
            this.btn_u.TabIndex = 1;
            this.btn_u.TabStop = false;
            this.btn_u.Text = "u";
            this.btn_u.UseVisualStyleBackColor = false;
            this.btn_u.Click += new System.EventHandler(this.Btn_u_Click);
            // 
            // btn_i
            // 
            this.btn_i.BackColor = System.Drawing.SystemColors.Control;
            this.btn_i.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_i.Location = new System.Drawing.Point(536, 83);
            this.btn_i.Name = "btn_i";
            this.btn_i.Size = new System.Drawing.Size(72, 72);
            this.btn_i.TabIndex = 2;
            this.btn_i.TabStop = false;
            this.btn_i.Text = "i";
            this.btn_i.UseVisualStyleBackColor = false;
            this.btn_i.Click += new System.EventHandler(this.Btn_i_Click);
            // 
            // btn_o
            // 
            this.btn_o.BackColor = System.Drawing.SystemColors.Control;
            this.btn_o.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_o.Location = new System.Drawing.Point(610, 83);
            this.btn_o.Name = "btn_o";
            this.btn_o.Size = new System.Drawing.Size(72, 72);
            this.btn_o.TabIndex = 3;
            this.btn_o.TabStop = false;
            this.btn_o.Text = "o";
            this.btn_o.UseVisualStyleBackColor = false;
            this.btn_o.Click += new System.EventHandler(this.Btn_o_Click);
            // 
            // btn_p
            // 
            this.btn_p.BackColor = System.Drawing.SystemColors.Control;
            this.btn_p.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_p.Location = new System.Drawing.Point(684, 83);
            this.btn_p.Name = "btn_p";
            this.btn_p.Size = new System.Drawing.Size(72, 72);
            this.btn_p.TabIndex = 4;
            this.btn_p.TabStop = false;
            this.btn_p.Text = "p";
            this.btn_p.UseVisualStyleBackColor = false;
            this.btn_p.Click += new System.EventHandler(this.Btn_p_Click);
            // 
            // btn_a
            // 
            this.btn_a.BackColor = System.Drawing.SystemColors.Control;
            this.btn_a.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_a.Location = new System.Drawing.Point(33, 158);
            this.btn_a.Name = "btn_a";
            this.btn_a.Size = new System.Drawing.Size(72, 72);
            this.btn_a.TabIndex = 5;
            this.btn_a.TabStop = false;
            this.btn_a.Text = "a";
            this.btn_a.UseVisualStyleBackColor = false;
            this.btn_a.Click += new System.EventHandler(this.Btn_a_Click);
            // 
            // btn_s
            // 
            this.btn_s.BackColor = System.Drawing.SystemColors.Control;
            this.btn_s.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_s.Location = new System.Drawing.Point(107, 158);
            this.btn_s.Name = "btn_s";
            this.btn_s.Size = new System.Drawing.Size(72, 72);
            this.btn_s.TabIndex = 6;
            this.btn_s.TabStop = false;
            this.btn_s.Text = "s";
            this.btn_s.UseVisualStyleBackColor = false;
            this.btn_s.Click += new System.EventHandler(this.Btn_s_Click);
            // 
            // btn_d
            // 
            this.btn_d.BackColor = System.Drawing.SystemColors.Control;
            this.btn_d.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_d.Location = new System.Drawing.Point(181, 158);
            this.btn_d.Name = "btn_d";
            this.btn_d.Size = new System.Drawing.Size(72, 72);
            this.btn_d.TabIndex = 7;
            this.btn_d.TabStop = false;
            this.btn_d.Text = "d";
            this.btn_d.UseVisualStyleBackColor = false;
            this.btn_d.Click += new System.EventHandler(this.Btn_d_Click);
            // 
            // btn_f
            // 
            this.btn_f.BackColor = System.Drawing.SystemColors.Control;
            this.btn_f.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_f.Location = new System.Drawing.Point(255, 158);
            this.btn_f.Name = "btn_f";
            this.btn_f.Size = new System.Drawing.Size(72, 72);
            this.btn_f.TabIndex = 8;
            this.btn_f.TabStop = false;
            this.btn_f.Text = "f";
            this.btn_f.UseVisualStyleBackColor = false;
            this.btn_f.Click += new System.EventHandler(this.Btn_f_Click);
            // 
            // btn_g
            // 
            this.btn_g.BackColor = System.Drawing.SystemColors.Control;
            this.btn_g.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_g.Location = new System.Drawing.Point(329, 158);
            this.btn_g.Name = "btn_g";
            this.btn_g.Size = new System.Drawing.Size(72, 72);
            this.btn_g.TabIndex = 9;
            this.btn_g.TabStop = false;
            this.btn_g.Text = "g";
            this.btn_g.UseVisualStyleBackColor = false;
            this.btn_g.Click += new System.EventHandler(this.Btn_g_Click);
            // 
            // btn_h
            // 
            this.btn_h.BackColor = System.Drawing.SystemColors.Control;
            this.btn_h.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_h.Location = new System.Drawing.Point(403, 158);
            this.btn_h.Name = "btn_h";
            this.btn_h.Size = new System.Drawing.Size(72, 72);
            this.btn_h.TabIndex = 10;
            this.btn_h.TabStop = false;
            this.btn_h.Text = "h";
            this.btn_h.UseVisualStyleBackColor = false;
            this.btn_h.Click += new System.EventHandler(this.Btn_h_Click);
            // 
            // btn_j
            // 
            this.btn_j.BackColor = System.Drawing.SystemColors.Control;
            this.btn_j.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_j.Location = new System.Drawing.Point(477, 158);
            this.btn_j.Name = "btn_j";
            this.btn_j.Size = new System.Drawing.Size(72, 72);
            this.btn_j.TabIndex = 11;
            this.btn_j.TabStop = false;
            this.btn_j.Text = "j";
            this.btn_j.UseVisualStyleBackColor = false;
            this.btn_j.Click += new System.EventHandler(this.Btn_j_Click);
            // 
            // btn_k
            // 
            this.btn_k.BackColor = System.Drawing.SystemColors.Control;
            this.btn_k.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_k.Location = new System.Drawing.Point(551, 158);
            this.btn_k.Name = "btn_k";
            this.btn_k.Size = new System.Drawing.Size(72, 72);
            this.btn_k.TabIndex = 12;
            this.btn_k.TabStop = false;
            this.btn_k.Text = "k";
            this.btn_k.UseVisualStyleBackColor = false;
            this.btn_k.Click += new System.EventHandler(this.Btn_k_Click);
            // 
            // btn_l
            // 
            this.btn_l.BackColor = System.Drawing.SystemColors.Control;
            this.btn_l.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_l.Location = new System.Drawing.Point(625, 158);
            this.btn_l.Name = "btn_l";
            this.btn_l.Size = new System.Drawing.Size(72, 72);
            this.btn_l.TabIndex = 13;
            this.btn_l.TabStop = false;
            this.btn_l.Text = "l";
            this.btn_l.UseVisualStyleBackColor = false;
            this.btn_l.Click += new System.EventHandler(this.Btn_l_Click);
            // 
            // btn_z
            // 
            this.btn_z.BackColor = System.Drawing.SystemColors.Control;
            this.btn_z.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_z.Location = new System.Drawing.Point(48, 233);
            this.btn_z.Name = "btn_z";
            this.btn_z.Size = new System.Drawing.Size(72, 72);
            this.btn_z.TabIndex = 14;
            this.btn_z.TabStop = false;
            this.btn_z.Text = "z";
            this.btn_z.UseVisualStyleBackColor = false;
            this.btn_z.Click += new System.EventHandler(this.Btn_z_Click);
            // 
            // btn_x
            // 
            this.btn_x.BackColor = System.Drawing.SystemColors.Control;
            this.btn_x.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_x.Location = new System.Drawing.Point(122, 233);
            this.btn_x.Name = "btn_x";
            this.btn_x.Size = new System.Drawing.Size(72, 72);
            this.btn_x.TabIndex = 15;
            this.btn_x.TabStop = false;
            this.btn_x.Text = "x";
            this.btn_x.UseVisualStyleBackColor = false;
            this.btn_x.Click += new System.EventHandler(this.Btn_x_Click);
            // 
            // btn_c
            // 
            this.btn_c.BackColor = System.Drawing.SystemColors.Control;
            this.btn_c.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_c.Location = new System.Drawing.Point(196, 233);
            this.btn_c.Name = "btn_c";
            this.btn_c.Size = new System.Drawing.Size(72, 72);
            this.btn_c.TabIndex = 16;
            this.btn_c.TabStop = false;
            this.btn_c.Text = "c";
            this.btn_c.UseVisualStyleBackColor = false;
            this.btn_c.Click += new System.EventHandler(this.Btn_c_Click);
            // 
            // btn_v
            // 
            this.btn_v.BackColor = System.Drawing.SystemColors.Control;
            this.btn_v.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_v.Location = new System.Drawing.Point(270, 233);
            this.btn_v.Name = "btn_v";
            this.btn_v.Size = new System.Drawing.Size(72, 72);
            this.btn_v.TabIndex = 17;
            this.btn_v.TabStop = false;
            this.btn_v.Text = "v";
            this.btn_v.UseVisualStyleBackColor = false;
            this.btn_v.Click += new System.EventHandler(this.Btn_v_Click);
            // 
            // btn_b
            // 
            this.btn_b.BackColor = System.Drawing.SystemColors.Control;
            this.btn_b.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_b.Location = new System.Drawing.Point(344, 233);
            this.btn_b.Name = "btn_b";
            this.btn_b.Size = new System.Drawing.Size(72, 72);
            this.btn_b.TabIndex = 18;
            this.btn_b.TabStop = false;
            this.btn_b.Text = "b";
            this.btn_b.UseVisualStyleBackColor = false;
            this.btn_b.Click += new System.EventHandler(this.Btn_b_Click);
            // 
            // btn_n
            // 
            this.btn_n.BackColor = System.Drawing.SystemColors.Control;
            this.btn_n.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_n.Location = new System.Drawing.Point(418, 233);
            this.btn_n.Name = "btn_n";
            this.btn_n.Size = new System.Drawing.Size(72, 72);
            this.btn_n.TabIndex = 19;
            this.btn_n.TabStop = false;
            this.btn_n.Text = "n";
            this.btn_n.UseVisualStyleBackColor = false;
            this.btn_n.Click += new System.EventHandler(this.Btn_n_Click);
            // 
            // btn_m
            // 
            this.btn_m.BackColor = System.Drawing.SystemColors.Control;
            this.btn_m.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_m.Location = new System.Drawing.Point(492, 233);
            this.btn_m.Name = "btn_m";
            this.btn_m.Size = new System.Drawing.Size(72, 72);
            this.btn_m.TabIndex = 20;
            this.btn_m.TabStop = false;
            this.btn_m.Text = "m";
            this.btn_m.UseVisualStyleBackColor = false;
            this.btn_m.Click += new System.EventHandler(this.Btn_m_Click);
            // 
            // btn_space
            // 
            this.btn_space.BackColor = System.Drawing.SystemColors.Control;
            this.btn_space.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_space.Location = new System.Drawing.Point(209, 308);
            this.btn_space.Name = "btn_space";
            this.btn_space.Size = new System.Drawing.Size(251, 72);
            this.btn_space.TabIndex = 23;
            this.btn_space.TabStop = false;
            this.btn_space.Text = "space";
            this.btn_space.UseVisualStyleBackColor = false;
            this.btn_space.Click += new System.EventHandler(this.Btn_space_Click);
            // 
            // btn_clear
            // 
            this.btn_clear.BackColor = System.Drawing.Color.Salmon;
            this.btn_clear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_clear.Location = new System.Drawing.Point(684, 233);
            this.btn_clear.Name = "btn_clear";
            this.btn_clear.Size = new System.Drawing.Size(72, 72);
            this.btn_clear.TabIndex = 24;
            this.btn_clear.TabStop = false;
            this.btn_clear.Text = "Clear";
            this.btn_clear.UseVisualStyleBackColor = false;
            this.btn_clear.Click += new System.EventHandler(this.Btn_clear_Click);
            // 
            // btn_1
            // 
            this.btn_1.BackColor = System.Drawing.SystemColors.Control;
            this.btn_1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_1.Location = new System.Drawing.Point(3, 8);
            this.btn_1.Name = "btn_1";
            this.btn_1.Size = new System.Drawing.Size(72, 72);
            this.btn_1.TabIndex = 25;
            this.btn_1.TabStop = false;
            this.btn_1.Text = "1";
            this.btn_1.UseVisualStyleBackColor = false;
            this.btn_1.Click += new System.EventHandler(this.Btn_1_Click);
            // 
            // btn_2
            // 
            this.btn_2.BackColor = System.Drawing.SystemColors.Control;
            this.btn_2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_2.Location = new System.Drawing.Point(77, 8);
            this.btn_2.Name = "btn_2";
            this.btn_2.Size = new System.Drawing.Size(72, 72);
            this.btn_2.TabIndex = 26;
            this.btn_2.TabStop = false;
            this.btn_2.Text = "2";
            this.btn_2.UseVisualStyleBackColor = false;
            this.btn_2.Click += new System.EventHandler(this.Btn_2_Click);
            // 
            // btn_4
            // 
            this.btn_4.BackColor = System.Drawing.SystemColors.Control;
            this.btn_4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_4.Location = new System.Drawing.Point(224, 8);
            this.btn_4.Name = "btn_4";
            this.btn_4.Size = new System.Drawing.Size(72, 72);
            this.btn_4.TabIndex = 27;
            this.btn_4.TabStop = false;
            this.btn_4.Text = "4";
            this.btn_4.UseVisualStyleBackColor = false;
            this.btn_4.Click += new System.EventHandler(this.Btn_4_Click);
            // 
            // btn_8
            // 
            this.btn_8.BackColor = System.Drawing.SystemColors.Control;
            this.btn_8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_8.Location = new System.Drawing.Point(516, 8);
            this.btn_8.Name = "btn_8";
            this.btn_8.Size = new System.Drawing.Size(72, 72);
            this.btn_8.TabIndex = 28;
            this.btn_8.TabStop = false;
            this.btn_8.Text = "8";
            this.btn_8.UseVisualStyleBackColor = false;
            this.btn_8.Click += new System.EventHandler(this.Btn_8_Click);
            // 
            // btn_9
            // 
            this.btn_9.BackColor = System.Drawing.SystemColors.Control;
            this.btn_9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_9.Location = new System.Drawing.Point(589, 8);
            this.btn_9.Name = "btn_9";
            this.btn_9.Size = new System.Drawing.Size(72, 72);
            this.btn_9.TabIndex = 29;
            this.btn_9.TabStop = false;
            this.btn_9.Text = "9";
            this.btn_9.UseVisualStyleBackColor = false;
            this.btn_9.Click += new System.EventHandler(this.Btn_9_Click);
            // 
            // btn_7
            // 
            this.btn_7.BackColor = System.Drawing.SystemColors.Control;
            this.btn_7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_7.Location = new System.Drawing.Point(443, 8);
            this.btn_7.Name = "btn_7";
            this.btn_7.Size = new System.Drawing.Size(72, 72);
            this.btn_7.TabIndex = 30;
            this.btn_7.TabStop = false;
            this.btn_7.Text = "7";
            this.btn_7.UseVisualStyleBackColor = false;
            this.btn_7.Click += new System.EventHandler(this.Btn_7_Click);
            // 
            // btn_q
            // 
            this.btn_q.BackColor = System.Drawing.SystemColors.Control;
            this.btn_q.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_q.Location = new System.Drawing.Point(18, 83);
            this.btn_q.Name = "btn_q";
            this.btn_q.Size = new System.Drawing.Size(72, 72);
            this.btn_q.TabIndex = 31;
            this.btn_q.TabStop = false;
            this.btn_q.Text = "q";
            this.btn_q.UseVisualStyleBackColor = false;
            this.btn_q.Click += new System.EventHandler(this.Btn_q_Click);
            // 
            // btn_0
            // 
            this.btn_0.BackColor = System.Drawing.SystemColors.Control;
            this.btn_0.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_0.Location = new System.Drawing.Point(662, 8);
            this.btn_0.Name = "btn_0";
            this.btn_0.Size = new System.Drawing.Size(72, 72);
            this.btn_0.TabIndex = 32;
            this.btn_0.TabStop = false;
            this.btn_0.Text = "0";
            this.btn_0.UseVisualStyleBackColor = false;
            this.btn_0.Click += new System.EventHandler(this.Btn_0_Click);
            // 
            // btn_5
            // 
            this.btn_5.BackColor = System.Drawing.SystemColors.Control;
            this.btn_5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_5.Location = new System.Drawing.Point(297, 8);
            this.btn_5.Name = "btn_5";
            this.btn_5.Size = new System.Drawing.Size(72, 72);
            this.btn_5.TabIndex = 33;
            this.btn_5.TabStop = false;
            this.btn_5.Text = "5";
            this.btn_5.UseVisualStyleBackColor = false;
            this.btn_5.Click += new System.EventHandler(this.Btn_5_Click);
            // 
            // btn_6
            // 
            this.btn_6.BackColor = System.Drawing.SystemColors.Control;
            this.btn_6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_6.Location = new System.Drawing.Point(370, 8);
            this.btn_6.Name = "btn_6";
            this.btn_6.Size = new System.Drawing.Size(72, 72);
            this.btn_6.TabIndex = 34;
            this.btn_6.TabStop = false;
            this.btn_6.Text = "6";
            this.btn_6.UseVisualStyleBackColor = false;
            this.btn_6.Click += new System.EventHandler(this.Btn_6_Click);
            // 
            // btn_w
            // 
            this.btn_w.BackColor = System.Drawing.SystemColors.Control;
            this.btn_w.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_w.Location = new System.Drawing.Point(92, 83);
            this.btn_w.Name = "btn_w";
            this.btn_w.Size = new System.Drawing.Size(72, 72);
            this.btn_w.TabIndex = 35;
            this.btn_w.TabStop = false;
            this.btn_w.Text = "w";
            this.btn_w.UseVisualStyleBackColor = false;
            this.btn_w.Click += new System.EventHandler(this.Btn_w_Click);
            // 
            // btn_e
            // 
            this.btn_e.BackColor = System.Drawing.SystemColors.Control;
            this.btn_e.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_e.Location = new System.Drawing.Point(166, 83);
            this.btn_e.Name = "btn_e";
            this.btn_e.Size = new System.Drawing.Size(72, 72);
            this.btn_e.TabIndex = 36;
            this.btn_e.TabStop = false;
            this.btn_e.Text = "e";
            this.btn_e.UseVisualStyleBackColor = false;
            this.btn_e.Click += new System.EventHandler(this.Btn_e_Click);
            // 
            // btn_r
            // 
            this.btn_r.BackColor = System.Drawing.SystemColors.Control;
            this.btn_r.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_r.Location = new System.Drawing.Point(240, 83);
            this.btn_r.Name = "btn_r";
            this.btn_r.Size = new System.Drawing.Size(72, 72);
            this.btn_r.TabIndex = 37;
            this.btn_r.TabStop = false;
            this.btn_r.Text = "r";
            this.btn_r.UseVisualStyleBackColor = false;
            this.btn_r.Click += new System.EventHandler(this.Btn_r_Click);
            // 
            // btn_t
            // 
            this.btn_t.BackColor = System.Drawing.SystemColors.Control;
            this.btn_t.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_t.Location = new System.Drawing.Point(314, 83);
            this.btn_t.Name = "btn_t";
            this.btn_t.Size = new System.Drawing.Size(72, 72);
            this.btn_t.TabIndex = 38;
            this.btn_t.TabStop = false;
            this.btn_t.Text = "t";
            this.btn_t.UseVisualStyleBackColor = false;
            this.btn_t.Click += new System.EventHandler(this.Btn_t_Click);
            // 
            // btn_y
            // 
            this.btn_y.BackColor = System.Drawing.SystemColors.Control;
            this.btn_y.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_y.Location = new System.Drawing.Point(388, 83);
            this.btn_y.Name = "btn_y";
            this.btn_y.Size = new System.Drawing.Size(72, 72);
            this.btn_y.TabIndex = 39;
            this.btn_y.TabStop = false;
            this.btn_y.Text = "y";
            this.btn_y.UseVisualStyleBackColor = false;
            this.btn_y.Click += new System.EventHandler(this.Btn_y_Click);
            // 
            // btn_cancel
            // 
            this.btn_cancel.BackColor = System.Drawing.SystemColors.Control;
            this.btn_cancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_cancel.Image = global::Keypad.Properties.Resources.Cancel64;
            this.btn_cancel.Location = new System.Drawing.Point(610, 308);
            this.btn_cancel.Name = "btn_cancel";
            this.btn_cancel.Size = new System.Drawing.Size(72, 72);
            this.btn_cancel.TabIndex = 40;
            this.btn_cancel.TabStop = false;
            this.btn_cancel.UseVisualStyleBackColor = false;
            this.btn_cancel.Click += new System.EventHandler(this.Btn_cancel_Click);
            // 
            // btn_OK
            // 
            this.btn_OK.BackColor = System.Drawing.SystemColors.Control;
            this.btn_OK.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_OK.Image = global::Keypad.Properties.Resources.OK64;
            this.btn_OK.Location = new System.Drawing.Point(684, 308);
            this.btn_OK.Name = "btn_OK";
            this.btn_OK.Size = new System.Drawing.Size(72, 72);
            this.btn_OK.TabIndex = 41;
            this.btn_OK.TabStop = false;
            this.btn_OK.UseVisualStyleBackColor = false;
            this.btn_OK.Click += new System.EventHandler(this.Btn_OK_Click);
            // 
            // btn_backspace
            // 
            this.btn_backspace.BackColor = System.Drawing.SystemColors.Control;
            this.btn_backspace.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_backspace.Location = new System.Drawing.Point(463, 308);
            this.btn_backspace.Name = "btn_backspace";
            this.btn_backspace.Size = new System.Drawing.Size(72, 72);
            this.btn_backspace.TabIndex = 42;
            this.btn_backspace.TabStop = false;
            this.btn_backspace.Text = "back space";
            this.btn_backspace.UseVisualStyleBackColor = false;
            this.btn_backspace.Click += new System.EventHandler(this.Btn_backspace_Click);
            // 
            // chk_shift
            // 
            this.chk_shift.Appearance = System.Windows.Forms.Appearance.Button;
            this.chk_shift.Location = new System.Drawing.Point(63, 308);
            this.chk_shift.Name = "chk_shift";
            this.chk_shift.Size = new System.Drawing.Size(72, 72);
            this.chk_shift.TabIndex = 43;
            this.chk_shift.Text = "shift";
            this.chk_shift.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chk_shift.UseVisualStyleBackColor = true;
            this.chk_shift.CheckedChanged += new System.EventHandler(this.Chk_shift_CheckedChanged);
            // 
            // chk_capslock
            // 
            this.chk_capslock.Appearance = System.Windows.Forms.Appearance.Button;
            this.chk_capslock.Location = new System.Drawing.Point(135, 308);
            this.chk_capslock.Name = "chk_capslock";
            this.chk_capslock.Size = new System.Drawing.Size(72, 72);
            this.chk_capslock.TabIndex = 44;
            this.chk_capslock.Text = "caps lock";
            this.chk_capslock.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chk_capslock.UseVisualStyleBackColor = true;
            this.chk_capslock.CheckedChanged += new System.EventHandler(this.Chk_capslock_CheckedChanged);
            // 
            // Keyboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.Controls.Add(this.chk_capslock);
            this.Controls.Add(this.chk_shift);
            this.Controls.Add(this.btn_backspace);
            this.Controls.Add(this.btn_OK);
            this.Controls.Add(this.btn_cancel);
            this.Controls.Add(this.btn_y);
            this.Controls.Add(this.btn_t);
            this.Controls.Add(this.btn_r);
            this.Controls.Add(this.btn_e);
            this.Controls.Add(this.btn_w);
            this.Controls.Add(this.btn_6);
            this.Controls.Add(this.btn_5);
            this.Controls.Add(this.btn_0);
            this.Controls.Add(this.btn_q);
            this.Controls.Add(this.btn_7);
            this.Controls.Add(this.btn_9);
            this.Controls.Add(this.btn_8);
            this.Controls.Add(this.btn_4);
            this.Controls.Add(this.btn_2);
            this.Controls.Add(this.btn_1);
            this.Controls.Add(this.btn_clear);
            this.Controls.Add(this.btn_space);
            this.Controls.Add(this.btn_m);
            this.Controls.Add(this.btn_n);
            this.Controls.Add(this.btn_b);
            this.Controls.Add(this.btn_v);
            this.Controls.Add(this.btn_c);
            this.Controls.Add(this.btn_x);
            this.Controls.Add(this.btn_z);
            this.Controls.Add(this.btn_l);
            this.Controls.Add(this.btn_k);
            this.Controls.Add(this.btn_j);
            this.Controls.Add(this.btn_h);
            this.Controls.Add(this.btn_g);
            this.Controls.Add(this.btn_f);
            this.Controls.Add(this.btn_d);
            this.Controls.Add(this.btn_s);
            this.Controls.Add(this.btn_a);
            this.Controls.Add(this.btn_p);
            this.Controls.Add(this.btn_o);
            this.Controls.Add(this.btn_i);
            this.Controls.Add(this.btn_u);
            this.Controls.Add(this.btn_3);
            this.Name = "Keyboard";
            this.Size = new System.Drawing.Size(760, 386);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_3;
        private System.Windows.Forms.Button btn_u;
        private System.Windows.Forms.Button btn_i;
        private System.Windows.Forms.Button btn_o;
        private System.Windows.Forms.Button btn_p;
        private System.Windows.Forms.Button btn_a;
        private System.Windows.Forms.Button btn_s;
        private System.Windows.Forms.Button btn_d;
        private System.Windows.Forms.Button btn_f;
        private System.Windows.Forms.Button btn_g;
        private System.Windows.Forms.Button btn_h;
        private System.Windows.Forms.Button btn_j;
        private System.Windows.Forms.Button btn_k;
        private System.Windows.Forms.Button btn_l;
        private System.Windows.Forms.Button btn_z;
        private System.Windows.Forms.Button btn_x;
        private System.Windows.Forms.Button btn_c;
        private System.Windows.Forms.Button btn_v;
        private System.Windows.Forms.Button btn_b;
        private System.Windows.Forms.Button btn_n;
        private System.Windows.Forms.Button btn_m;
        private System.Windows.Forms.Button btn_space;
        private System.Windows.Forms.Button btn_clear;
        private System.Windows.Forms.Button btn_1;
        private System.Windows.Forms.Button btn_2;
        private System.Windows.Forms.Button btn_4;
        private System.Windows.Forms.Button btn_8;
        private System.Windows.Forms.Button btn_9;
        private System.Windows.Forms.Button btn_7;
        private System.Windows.Forms.Button btn_q;
        private System.Windows.Forms.Button btn_0;
        private System.Windows.Forms.Button btn_5;
        private System.Windows.Forms.Button btn_6;
        private System.Windows.Forms.Button btn_w;
        private System.Windows.Forms.Button btn_e;
        private System.Windows.Forms.Button btn_r;
        private System.Windows.Forms.Button btn_t;
        private System.Windows.Forms.Button btn_y;
        private System.Windows.Forms.Button btn_cancel;
        private System.Windows.Forms.Button btn_OK;
        private System.Windows.Forms.Button btn_backspace;
        private System.Windows.Forms.CheckBox chk_shift;
        private System.Windows.Forms.CheckBox chk_capslock;
    }
}
