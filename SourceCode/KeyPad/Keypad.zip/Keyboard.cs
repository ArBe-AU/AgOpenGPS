﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Keypad
{
    public partial class Keyboard : GenericKeypad
    {
        public Keyboard()
        {
            InitializeComponent();
        }

        private void Btn_1_Click(object sender, EventArgs e)
        {
            RaiseButtonPressed('1');
        }

        private void Btn_2_Click(object sender, EventArgs e)
        {
            RaiseButtonPressed('2');
        }

        private void Btn_3_Click(object sender, EventArgs e)
        {
            RaiseButtonPressed('3');
        }

        private void Btn_4_Click(object sender, EventArgs e)
        {
            RaiseButtonPressed('4');
        }

        private void Btn_5_Click(object sender, EventArgs e)
        {
            RaiseButtonPressed('5');
        }

        private void Btn_6_Click(object sender, EventArgs e)
        {
            RaiseButtonPressed('6');
        }

        private void Btn_7_Click(object sender, EventArgs e)
        {
            RaiseButtonPressed('7');
        }

        private void Btn_8_Click(object sender, EventArgs e)
        {
            RaiseButtonPressed('8');
        }

        private void Btn_9_Click(object sender, EventArgs e)
        {
            RaiseButtonPressed('9');
        }

        private void Btn_0_Click(object sender, EventArgs e)
        {
            RaiseButtonPressed('0');
        }

        private void Btn_q_Click(object sender, EventArgs e)
        {
            if (chk_capslock.Checked == true || chk_shift.Checked == true)
            {
                RaiseButtonPressed('Q');
                chk_shift.Checked = false;
            }
            else
            {
                RaiseButtonPressed('q');
            }
        }

        private void Btn_w_Click(object sender, EventArgs e)
        {
            if (chk_capslock.Checked == true || chk_shift.Checked == true)
            {
                RaiseButtonPressed('W');
                chk_shift.Checked = false;
            }
            else
            {
                RaiseButtonPressed('w');
            }
        }

        private void Btn_e_Click(object sender, EventArgs e)
        {
            if (chk_capslock.Checked == true || chk_shift.Checked == true)
            {
                RaiseButtonPressed('E');
                chk_shift.Checked = false;
            }
            else
            {
                RaiseButtonPressed('e');
            }
        }

        private void Btn_r_Click(object sender, EventArgs e)
        {
            if (chk_capslock.Checked == true || chk_shift.Checked == true)
            {
                RaiseButtonPressed('R');
                chk_shift.Checked = false;
            }
            else
            {
                RaiseButtonPressed('r');
            }
        }

        private void Btn_t_Click(object sender, EventArgs e)
        {
            if (chk_capslock.Checked == true || chk_shift.Checked == true)
            {
                RaiseButtonPressed('T');
                chk_shift.Checked = false;
            }
            else
            {
                RaiseButtonPressed('t');
            }
        }

        private void Btn_y_Click(object sender, EventArgs e)
        {
            if (chk_capslock.Checked == true || chk_shift.Checked == true)
            {
                RaiseButtonPressed('Y');
                chk_shift.Checked = false;
            }
            else
            {
                RaiseButtonPressed('y');
            }
        }

        private void Btn_u_Click(object sender, EventArgs e)
        {
            if (chk_capslock.Checked == true || chk_shift.Checked == true)
            {
                RaiseButtonPressed('U');
                chk_shift.Checked = false;
            }
            else
            {
                RaiseButtonPressed('u');
            }
        }

        private void Btn_i_Click(object sender, EventArgs e)
        {
            if (chk_capslock.Checked == true || chk_shift.Checked == true)
            {
                RaiseButtonPressed('I');
                chk_shift.Checked = false;
            }
            else
            {
                RaiseButtonPressed('i');
            }
        }

        private void Btn_o_Click(object sender, EventArgs e)
        {
            if (chk_capslock.Checked == true || chk_shift.Checked == true)
            {
                RaiseButtonPressed('O');
                chk_shift.Checked = false;
            }
            else
            {
                RaiseButtonPressed('o');
            }
        }

        private void Btn_p_Click(object sender, EventArgs e)
        {
            if (chk_capslock.Checked == true || chk_shift.Checked == true)
            {
                RaiseButtonPressed('P');
                chk_shift.Checked = false;
            }
            else
            {
                RaiseButtonPressed('p');
            }
        }

        private void Btn_a_Click(object sender, EventArgs e)
        {
            if (chk_capslock.Checked == true || chk_shift.Checked == true)
            {
                RaiseButtonPressed('A');
                chk_shift.Checked = false;
            }
            else
            {
                RaiseButtonPressed('a');
            }
        }

        private void Btn_s_Click(object sender, EventArgs e)
        {
            if (chk_capslock.Checked == true || chk_shift.Checked == true)
            {
                RaiseButtonPressed('S');
                chk_shift.Checked = false;
            }
            else
            {
                RaiseButtonPressed('s');
            }
        }

        private void Btn_d_Click(object sender, EventArgs e)
        {
            if (chk_capslock.Checked == true || chk_shift.Checked == true)
            {
                RaiseButtonPressed('D');
                chk_shift.Checked = false;
            }
            else
            {
                RaiseButtonPressed('d');
            }
        }

        private void Btn_f_Click(object sender, EventArgs e)
        {
            if (chk_capslock.Checked == true || chk_shift.Checked == true)
            {
                RaiseButtonPressed('F');
                chk_shift.Checked = false;
            }
            else
            {
                RaiseButtonPressed('f');
            }
        }

        private void Btn_g_Click(object sender, EventArgs e)
        {
            if (chk_capslock.Checked == true || chk_shift.Checked == true)
            {
                RaiseButtonPressed('F');
                chk_shift.Checked = false;
            }
            else
            {
                RaiseButtonPressed('f');
            }
        }

        private void Btn_h_Click(object sender, EventArgs e)
        {
            if (chk_capslock.Checked == true || chk_shift.Checked == true)
            {
                RaiseButtonPressed('H');
                chk_shift.Checked = false;
            }
            else
            {
                RaiseButtonPressed('h');
            }
        }

        private void Btn_j_Click(object sender, EventArgs e)
        {
            if (chk_capslock.Checked == true || chk_shift.Checked == true)
            {
                RaiseButtonPressed('J');
                chk_shift.Checked = false;
            }
            else
            {
                RaiseButtonPressed('j');
            }
        }

        private void Btn_k_Click(object sender, EventArgs e)
        {
            if (chk_capslock.Checked == true || chk_shift.Checked == true)
            {
                RaiseButtonPressed('K');
                chk_shift.Checked = false;
            }
            else
            {
                RaiseButtonPressed('k');
            }
        }

        private void Btn_l_Click(object sender, EventArgs e)
        {
            if (chk_capslock.Checked == true || chk_shift.Checked == true)
            {
                RaiseButtonPressed('L');
                chk_shift.Checked = false;
            }
            else
            {
                RaiseButtonPressed('l');
            }
        }

        private void Btn_z_Click(object sender, EventArgs e)
        {
            if (chk_capslock.Checked == true || chk_shift.Checked == true)
            {
                RaiseButtonPressed('Z');
                chk_shift.Checked = false;
            }
            else
            {
                RaiseButtonPressed('z');
            }
        }

        private void Btn_x_Click(object sender, EventArgs e)
        {
            if (chk_capslock.Checked == true || chk_shift.Checked == true)
            {
                RaiseButtonPressed('X');
                chk_shift.Checked = false;
            }
            else
            {
                RaiseButtonPressed('x');
            }
        }

        private void Btn_c_Click(object sender, EventArgs e)
        {
            if (chk_capslock.Checked == true || chk_shift.Checked == true)
            {
                RaiseButtonPressed('C');
                chk_shift.Checked = false;
            }
            else
            {
                RaiseButtonPressed('c');
            }
        }

        private void Btn_v_Click(object sender, EventArgs e)
        {
            if (chk_capslock.Checked == true || chk_shift.Checked == true)
            {
                RaiseButtonPressed('V');
                chk_shift.Checked = false;
            }
            else
            {
                RaiseButtonPressed('v');
            }
        }

        private void Btn_b_Click(object sender, EventArgs e)
        {
            if (chk_capslock.Checked == true || chk_shift.Checked == true)
            {
                RaiseButtonPressed('B');
                chk_shift.Checked = false;
            }
            else
            {
                RaiseButtonPressed('b');
            }
        }

        private void Btn_n_Click(object sender, EventArgs e)
        {
            if (chk_capslock.Checked == true || chk_shift.Checked == true)
            {
                RaiseButtonPressed('N');
                chk_shift.Checked = false;
            }
            else
            {
                RaiseButtonPressed('n');
            }
        }

        private void Btn_m_Click(object sender, EventArgs e)
        {
            if (chk_capslock.Checked == true || chk_shift.Checked == true)
            {
                RaiseButtonPressed('M');
                chk_shift.Checked = false;
            }
            else
            {
                RaiseButtonPressed('m');
            }
        }

        private void Btn_space_Click(object sender, EventArgs e)
        {
            RaiseButtonPressed(' ');
        }

        private void Btn_backspace_Click(object sender, EventArgs e)
        {
            RaiseButtonPressed('<');
        }

        private void Btn_clear_Click(object sender, EventArgs e)
        {
            RaiseButtonPressed('?');
        }

        private void Btn_cancel_Click(object sender, EventArgs e)
        {
            RaiseButtonPressed('>');
        }

        private void Btn_OK_Click(object sender, EventArgs e)
        {
            RaiseButtonPressed(':');
        }

        private void changeCase()
        {
            if (chk_shift.Checked == true || chk_capslock.Checked == true)
            {
                btn_q.Text = "Q";
                btn_w.Text = "W";
                btn_e.Text = "E";
                btn_r.Text = "R";
                btn_t.Text = "T";
                btn_y.Text = "Y";
                btn_u.Text = "U";
                btn_i.Text = "I";
                btn_o.Text = "O";
                btn_p.Text = "P";
                btn_a.Text = "A";
                btn_s.Text = "S";
                btn_d.Text = "D";
                btn_f.Text = "F";
                btn_g.Text = "G";
                btn_h.Text = "H";
                btn_j.Text = "J";
                btn_k.Text = "K";
                btn_l.Text = "L";
                btn_z.Text = "Z";
                btn_x.Text = "X";
                btn_c.Text = "C";
                btn_v.Text = "V";
                btn_b.Text = "B";
                btn_n.Text = "N";
                btn_m.Text = "M";
            }
            else
            {
                btn_q.Text = "q";
                btn_w.Text = "w";
                btn_e.Text = "e";
                btn_r.Text = "r";
                btn_t.Text = "t";
                btn_y.Text = "y";
                btn_u.Text = "u";
                btn_i.Text = "i";
                btn_o.Text = "o";
                btn_p.Text = "p";
                btn_a.Text = "a";
                btn_s.Text = "s";
                btn_d.Text = "d";
                btn_f.Text = "f";
                btn_g.Text = "g";
                btn_h.Text = "h";
                btn_j.Text = "j";
                btn_k.Text = "k";
                btn_l.Text = "l";
                btn_z.Text = "z";
                btn_x.Text = "x";
                btn_c.Text = "c";
                btn_v.Text = "v";
                btn_b.Text = "b";
                btn_n.Text = "n";
                btn_m.Text = "m";
            }
        }

        private void Chk_shift_CheckedChanged(object sender, EventArgs e)
        {
            changeCase();
        }

        private void Chk_capslock_CheckedChanged(object sender, EventArgs e)
        {
            changeCase();
        }

    }
}
